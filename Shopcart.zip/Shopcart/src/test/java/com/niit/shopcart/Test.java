package com.niit.shopcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test {

	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.shopcart");
		context.refresh();
		
		Category c=(Category)context.getBean("category");
		c.setId("123a");
		System.out.println(c.getId());
		
		Product p=(Product)context.getBean("product");
		p.setId("abc567");
		System.out.println(p.getId());
		System.out.println(" product is created");
	}
	
}
