package com.niit.ecart;

public class LoginDAO {
	public boolean isValidUser(String userID, String Password)
	{
	if(userID.equals(Password))
	{
		return true;
	}
	else
	{
		return false;
	}

}
}
