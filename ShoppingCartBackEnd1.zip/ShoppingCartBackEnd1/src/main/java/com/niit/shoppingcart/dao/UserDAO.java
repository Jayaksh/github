package com.niit.shoppingcart.dao;

import java.util.List;

import com.niit.shoppingcart.model.User;


public interface UserDAO {

	public User getUser(String id);
	public void saveOrUpdate(User user);
	public void delete(String id);
	public List<User> list();
	public boolean isValidUser(String name,String password);
	
}
